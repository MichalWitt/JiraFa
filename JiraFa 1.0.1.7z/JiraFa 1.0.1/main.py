import urllib.request
import os
import shutil
import logging
import re
import warnings
from tkinter import Button, Text, filedialog, font, PhotoImage, messagebox
import tkinter as tk
from distutils.version import LooseVersion
global current_version
current_version = '1.0.1'
warnings.filterwarnings("ignore", message="distutils Version classes are deprecated")

#uruchomienie loggera, wyświetlanie logów w konsoli
with open('log.txt', 'w') as file:
    file.write(f"JiraFa, version: {current_version}\n")
logging.basicConfig(filename='log.txt', level=logging.INFO,
                    format='%(asctime)s: %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logging.getLogger().addHandler(logging.StreamHandler())
logging.info('=====JiraFa has been launched...=====')

def update(version, current_version):#sprawdzenie czy jest dostępna nowa wersja aplikacji
    messagebox.showinfo("Aktualizacja", f"Dostępna nowa wersja pogramu: {version}\nObecna wersja: {current_version}")

url = 'https://raw.githubusercontent.com/MichalWitt/JiraFa/main/version.txt'
urllib.request.urlretrieve(url, 'version.txt')
with open('version.txt', 'r') as file:
    version = file.read().strip()

logging.info(f'Checking for new version of JiraFa...')
if LooseVersion(version) > LooseVersion(current_version):
    update(version, current_version)
    logging.info(f'New version of JiraFa - {version} is available')
else:
    logging.info(f'JiraFa {current_version} is up to date')

# Funkcje pomocnicze
def find_config_ini(path):#szukanie pliku config.ini
    for root, dirs, files in os.walk(path):
        if 'config.ini' in files:
            logging.info('File config.ini found')
            return os.path.join(root, 'config.ini')  
    return None

def find_info_log(path):#szukanie pliku info.log
    for root, dirs, files in os.walk(path):
        if 'info.log' in files:
            logging.info('File info.log found')
            return os.path.join(root, 'info.log')
    return None

config_dict = {}
gta_dict = {}
testname_dict = {}
typ = []

#PRZESZUKIWANIE ZAWARTOŚCI PLIKU info.log
def find_ti():
    global gta_dict
    global testname_dict
    global typ
    with open('./tmp/info.log', 'r') as file:
        ti = []
        ti_links = []
        names = []
        names_links = []
        typ = []
        for line in file:
            line = line.strip()
            if 'Starting uploading process for config directory' in line:
                parts = line.split('"', 1)
                names.append(parts[1])#dodanie nazw do listy names               
            if 'Created new TestItem' in line:
                parts = line.split('"', 1)
                ti.append(parts[1])#dodanie ti do listy ti
        names_links.extend(names)#zapełnienie listy names_links
        for i in range(len(ti)):
            ti[i] = ti[i].replace('"', '')#edycja ti w liście

        #lista ti_links    
        ti_links.extend(ti)#dodanie ti links do listy ti_links
        prefix_ti_links = "https://gta.intel.com/#/testplanning/automatedtest/" 
        for i in range(len(ti_links)):#dodawanie prefixu do każdego elementu listy ti_links 
            ti_links[i] = prefix_ti_links + ti_links[i]
        
        #lista names_links    
        prefix_names_links = "https://gfx-assets.igk.intel.com/artifactory/gfx-3d-scate-assets-igk/traces/"
        sufix_names_links = "/trace/1.0/"
        for i in range (len(names_links)):#edycja, dodawanie prefixu/sufixu do każdego elementu listy names_links
            if "dx" in names_links[i]:
                names_links[i] = names_links[i].split('dx', 1)[1]
                names_links[i] = 'dx' + names_links[i]
                names_links[i] = names_links[i].replace('"', '')
                names_links[i] = names_links[i].replace('\\', '/')
                names_links[i] = prefix_names_links + names_links[i] + sufix_names_links
            if "vulkan" in names_links[i]:
                names_links[i] = names_links[i].split('vulkan', 1)[1]
                names_links[i] = 'vulkan' + names_links[i]
                names_links[i] = names_links[i].replace('"', '')
                names_links[i] = names_links[i].replace('\\', '/')
                names_links[i] = prefix_names_links + names_links[i] + sufix_names_links
            if "ogl" in names_links[i]:
                names_links[i] = names_links[i].split('ogl', 1)[1]
                names_links[i] = 'ogl' + names_links[i]
                names_links[i] = names_links[i].replace('"', '')
                names_links[i] = names_links[i].replace('\\', '/')
                names_links[i] = prefix_names_links + names_links[i] + sufix_names_links
        
        #lista names
        for i in range(len(names)):
            if 'dx' in names[i]:
                names[i] = names[i].split('dx', 1)[1]
                names[i] = names[i].replace('\\', '_')
                names[i] = names[i].replace('"', '')
                names[i] = 'dx' + names[i]
            if 'vulkan' in names[i]:
                names[i] = names[i].split('vulkan', 1)[1]
                names[i] = names[i].replace('\\', '_')
                names[i] = names[i].replace('"', '')
                names[i] = 'vulkan' + names[i]    
            if 'ogl' in names[i]:
                names[i] = names[i].split('ogl', 1)[1]
                names[i] = names[i].replace('\\', '_')
                names[i] = names[i].replace('"', '')
                names[i] = 'ogl' + names[i]
            if "main" in names[i]:
                typ.append('main')
            elif "full" in names[i]:
                typ.append('full')
            elif "rsa" in names[i]:
                typ.append('rsa')
            else:
                typ.append('1-frame')

        
    #DODAWANIE PAR DO SŁOWNIKÓW gta_dict i testname_dict
    for ti_element, ti_links_element in zip(ti, ti_links):#dodawanie pary ti, ti_links do słownika gta_dict
        gta_dict[ti_element] = ti_links_element
    for names_element, names_links_element in zip(names, names_links):#dodawanie pary names, names_links do słownika testname_dict
        testname_dict[names_element] = names_links_element

def find_txt():#przeszukiwanie pliku config.ini, kopiowanie wartości do słownika config_dict
    global config_dict
    with open('./tmp/config.ini', 'r') as file:
        for line in file:
            line = line.strip()
            if 'ToolName' in line:
                key, value = line.split('=', 1)
                config_dict[key] = value
            if 'ToolVersion' in line:
                key, value = line.split('=', 1)
                config_dict[key] = value
            if 'CaptureCommand' in line:
                key, value = line.split('=', 1)
                value = re.sub(r"\s*(-t\s+\S+|--tempdir\s+\S+)\s*", " ", value).strip()
                config_dict[key] = value
            if 'Version' in line:
                key, value = line.split('=', 1)
                config_dict[key] = value
            if 'GraphicsApi' in line:
                key, value = line.split('=', 1)
                config_dict[key] = value
            if 'VendorType' in line:
                key, value = line.split('=', 1)
                config_dict[key] = value
            if 'VendorBuild' in line:
                key, value = line.split('=', 1)
                config_dict[key] = value

class JiraFa:

    def __init__(self, root):
        global clip
        clip = PhotoImage(file='./icons/clip.png')

        def copy_to_clipboard(text):
            root.clipboard_clear()
            root.clipboard_append(text)
            root.update()

        def on_button1_click():
            text_to_copy = self.game_info_text.get('1.0', 'end-1c')
            copy_to_clipboard(text_to_copy)

        def on_button2_click():
            text_to_copy = self.stream_info_text.get('1.0', 'end-1c')
            copy_to_clipboard(text_to_copy)

        def on_button3_click():
            text_to_copy = self.test_items_text.get('1.0', 'end-1c')
            copy_to_clipboard(text_to_copy)

        bold_font = font.Font(family='Helvetica', size=10, weight='bold')
        self.root = root
        self.root.title(f'JiraFa, ver. {current_version}')
        self.root.iconbitmap('./icons/logo.ico')
        self.login_btn = PhotoImage(file = "./icons/1.png") 
        root.config(bg='#28282B')
        #PRZYCISK FIND TETRA
        #self.generate_button = Button(root, text='Find Tetra', bg="#572649",fg="white", font=bold_font, relief='raised', bd=2, command=self.generate_and_display)
        self.generate_button = Button(root, image=self.login_btn, bg='#28282B', borderwidth=0, highlightthickness=0, activebackground='#28282B', command=self.generate_and_display)
        self.generate_button.pack(pady=(20, 0))
        #PRZYCISK BOCZNY NR 1
        self.button1 = Button(root, text="Game_Info   ", image=clip, compound='right', font=bold_font, command=on_button1_click)
        self.button1.pack(anchor='w', padx=20)
        #POLE TEKSTOWE NR 1
        self.game_info_text = Text(root, bg="#BEBEBE", height=10, width=120)
        self.game_info_text.pack(fill='both', expand=True, padx=20, pady=10)
        #PRZYCISK BOCZNY NR 2
        self.button2 = Button(root, text="Stream_Info ", image=clip, compound='right', font=bold_font, command=on_button2_click)
        self.button2.pack(anchor='w', padx=20)
        #POLE TEKSTOWE NR 2
        self.stream_info_text = Text(root, bg="#BEBEBE", height=10)
        self.stream_info_text.pack(fill='both', expand=True, padx=20, pady=10)
        #PRZYCISK BOCZNY NR 3
        self.button3 = Button(root, text="Test_Items   ", image=clip, compound='right', font=bold_font, command=on_button3_click)
        self.button3.pack(anchor='w', padx=20)
        #POLE TEKSTOWE NR 3
        self.test_items_text = Text(root, bg="#BEBEBE", height=10, wrap='word')
        self.test_items_text.pack(fill='both', expand=True, padx=20, pady=10)
        #dolny pasek
        status_bar = tk.Label(root, text="Created by mwitczax. Intel Corporation, 2024.", bd=1, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)
       
    #tworzenie folderu ./tmp
    def generate_and_display(self):
        
        path = './tmp'
        global path_txt 
        path_txt = './txt'
        if not os.path.exists(path):
            os.makedirs(path)
            logging.info(f"Katalog '{path}' został pomyślnie utworzony")
        else:
            logging.info(f"Katalog '{path}' już istnieje")
        if not os.path.exists(path_txt):
            os.makedirs(path_txt)
            logging.info(f"Katalog '{path_txt}' został pomyślnie utworzony")
        else:
            logging.info(f"Katalog '{path_txt}' już istnieje")
        self.select_path()

    def select_path(self):
        # Wkazanie lokalizacji Tetry
        tetra_path = filedialog.askdirectory(initialdir="C://", title="Select Directory")
        logging.info(f"Tetra path selected: {tetra_path}")
        if tetra_path:
            config_path = find_config_ini(tetra_path)# uruchomienie funkcji znajdującej plik config.ini
            log_path = find_info_log(tetra_path)#uruchomienie funkcji znajdującej plik info.log
            if config_path:
                shutil.copy(config_path, './tmp/')
                logging.info("Skopiowano plik config.ini fo folderu ./tmp")#kopiowanie pliku config.ini do folderu ./tmp
            else:
                logging.error("Nie znaleziono pliku config.ini")
            if log_path:
                shutil.copy(log_path, './tmp/')  #kopiowanie pliku info.log do folderu ./tmp
                logging.info("Skopiowano plik info.log fo folderu ./tmp")
            else:
                logging.error("Nie znaleziono info.log")

            find_txt()
            find_ti()

            #TWORZENIE PLIKÓW TEKSTOWYCH
            with open('./txt/stream_info.txt', 'w') as file:
                file.write("||Capture Tool||Tool Version||Capture Command||Playback Command||\n")
                playback_command = 'GfxPlayer.exe <stream.lcs2>'
                file.write(f"|{config_dict.get('ToolName')}|{config_dict.get('ToolVersion')}|{config_dict.get('CaptureCommand')}|{playback_command}|")

            with open('./txt/game_info.txt', 'w') as file:
                file.write("||Application Version||Vendor Build ID||Vendor||Benchmark available||Default API||Optional API||Connection type||\n")
                benchmark_available = 'no'
                optional_api = '-'
                connection = 'LAB'
                file.write(f"|{config_dict.get('Version')}|{config_dict.get('VendorBuild')}|{config_dict.get('VendorType')}|{benchmark_available}|{config_dict.get('GraphicsApi')}|{optional_api}|{connection}|")

            with open('./txt/test_items.txt', 'w', encoding='utf-8') as plik:
                plik.write("||GTA||Test Name||Type||\n")
                for klucz1, klucz2, i in zip(gta_dict, testname_dict, typ):# Iteruj przez klucze pierwszego słownika
                    plik.write(f"|[{klucz1}|{gta_dict[klucz1]}]|[{klucz2}|{testname_dict[klucz2]}]|{i}|\n")#Zapis pary z pierwszego słownika i pary z drugiego słownika         
            file_path = './txt/test_items.txt'

            # Odczytaj zawartość pliku
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()

            # Usuń ostatni znak (jeśli plik nie jest pusty)
            if content:
                content = content[:-1]

            # Zapisz zmodyfikowaną zawartość z powrotem do pliku
            with open(file_path, 'w', encoding='utf-8') as file:
                file.write(content)

            print("Ostatni znak został usunięty z pliku.")

            self.update_text_fields()  # Aktualizacja pola tekstowego po przetworzeniu
            
       
    # Wczytanie i wyświetlenie zawartości plików tekstowych polach tekstowych aplikacji
    def update_text_fields(self):
           
        try:
            with open('./txt/stream_info.txt', 'r') as file:
                self.stream_info_text.delete('1.0', 'end')
                self.stream_info_text.insert('1.0', file.read())
                logging.info(f"{path_txt}/stream_info.txt has been created and loaded successfully.")
        except FileNotFoundError:
            self.stream_info_text.delete('1.0', 'end')
            self.stream_info_text.insert('1.0', 'Nie znaleziono pliku stream_info.txt')
            logging.error(f"{path_txt}/stream_info.txt not found.")
        try:
            with open('./txt/game_info.txt', 'r') as file:
                self.game_info_text.delete('1.0', 'end')
                self.game_info_text.insert('1.0', file.read())
                logging.info(f"{path_txt}/game_info.txt has been created and loaded successfully.")
        except FileNotFoundError:
            self.game_info_text.delete('1.0', 'end')
            self.game_info_text.insert('1.0', 'Nie znaleziono pliku game_info.txt')
            logging.error(f"{path_txt}/game_info not found.")  
        try:
            with open('./txt/test_items.txt', 'r') as file:
                self.test_items_text.delete('1.0', 'end')
                self.test_items_text.insert('1.0', file.read())
                logging.info(f"{path_txt}/test_items.txt has been created and loaded successfully.")
        except FileNotFoundError:
            self.test_items_text.delete('1.0', 'end')
            self.test_items_text.insert('1.0', 'Nie znaleziono pliku test_items.txt')
            logging.error(f"{path_txt}/test_items.txt not found.")
        #dopasowanie szerokości okna do nowej zawartości
        root.update_idletasks()
# Uruchomienie aplikacji
if __name__ == '__main__':
    root = tk.Tk()
    app = JiraFa(root)
    root.mainloop()